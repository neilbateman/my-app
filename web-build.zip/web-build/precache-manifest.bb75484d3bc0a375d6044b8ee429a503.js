self.__precacheManifest = [
  {
    "revision": "26b345312f581d520106",
    "url": "/static/js/app.5e4c80ce.chunk.js"
  },
  {
    "revision": "66090dc4495d4ce3dfb9",
    "url": "/static/js/runtime~app.2e9f1821.js"
  },
  {
    "revision": "28a308665c45f0ac4328",
    "url": "/static/js/2.804e53c2.chunk.js"
  },
  {
    "revision": "b9fcf7554fd87c46861c168952b3d6e1",
    "url": "/static/media/neil.349229c4.webp"
  },
  {
    "revision": "68a58f34108defdea27d1979cd22e60f",
    "url": "/static/media/gitlab-rgb.0c160ebc.png"
  },
  {
    "revision": "74e628dff7154ba85d537dc4481ea05e",
    "url": "/static/media/Octocat.8eb652b7.png"
  },
  {
    "revision": "8066803782685f7b8480ee84e09a072c",
    "url": "/static/media/linky.dca3fa26.png"
  },
  {
    "revision": "0afe363db86552dffe8bcb8673ba6625",
    "url": "/static/media/nb.93be3526.webp"
  },
  {
    "revision": "08e034e6f1eb2a3be16d7015a290794d",
    "url": "/index.html"
  },
  {
    "revision": "e318fe2d43ea6c821ae191cd4bda1ce8",
    "url": "/manifest.json"
  },
  {
    "revision": "ec543248d7b23864564429fc03837190",
    "url": "/serve.json"
  },
  {
    "revision": "2002987acac9deb6803ab4ba381226ba",
    "url": "/expo-service-worker.js"
  },
  {
    "revision": "e802d2644326fd9fa701f1d969a8a94a",
    "url": "/register-service-worker.js"
  },
  {
    "revision": "d4b9583852996254d9a5b908c50798f8",
    "url": "/static/js/2.804e53c2.chunk.js.LICENSE.txt"
  },
  {
    "revision": "518470eea7323c447ef1b6c62cd46222",
    "url": "/favicon-16.png"
  },
  {
    "revision": "adb64b08d5f091e169891960b4dfdfa4",
    "url": "/favicon-32.png"
  },
  {
    "revision": "955f81b366663a793b623fe415ac257d",
    "url": "/favicon.ico"
  }
];